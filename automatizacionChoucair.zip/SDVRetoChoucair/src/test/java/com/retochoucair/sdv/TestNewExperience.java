package com.retochoucair.sdv;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestNewExperience {

	private WebDriver driver;
	
	@Before
	public void setUp() {
		
		
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
	}
	
	@Test
	public void testeandoNewExperience() {
		
		WebElement correo = driver.findElement(By.name("email"));
		WebElement clave = driver.findElement(By.name("passwd"));
		WebElement iniciar = driver.findElement(By.name("SubmitLogin"));
		
		correo.clear();
		clave.clear();
		
		correo.sendKeys("soporte1998@gmail.com");
		clave.sendKeys("SDV199804");
		
		iniciar.click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		assertEquals("Login - My Store", driver.getTitle());
		
		
	}
	
	@After
	public void fintest() {
		/*driver.quit();*/
	}
	
}
